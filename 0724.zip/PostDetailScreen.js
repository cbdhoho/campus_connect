import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, Button, Image, Keyboard } from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Menu, Provider } from 'react-native-paper';
import moment from 'moment';

const formatRelativeTime = (time) => {
  const postTime = moment(time);
  return moment().diff(postTime, 'days') >= 1 ? postTime.format('YYYY-MM-DD') : postTime.fromNow();
};

const PostDetailScreen = () => {
  const route = useRoute();
  const { post, selectedUniversity } = route.params;
  const [likes, setLikes] = useState(post.likes);
  const [liked, setLiked] = useState(false);
  const [scrapped, setScrapped] = useState(post.scrapped);
  const [menuVisible, setMenuVisible] = useState(false);
  const [answers, setAnswers] = useState([]);
  const [commenting, setCommenting] = useState(null);
  const navigation = useNavigation();

  const toggleLike = () => {
    setLikes(likes + (liked ? -1 : 1));
    setLiked(!liked);
  };

  const toggleScrap = () => {
    setScrapped(!scrapped);
  };

  const addAnswer = (newAnswer) => {
    setAnswers(prevAnswers => [newAnswer, ...prevAnswers]); // Add the new answer to the list
  };

  const addComment = (answerId, newComment) => {
    setAnswers(prevAnswers => prevAnswers.map(answer => 
      answer.id === answerId ? { ...answer, comments: [newComment, ...(answer.comments || [])] } : answer
    ));
  };

  const toggleCommentLike = (answerId, commentId) => {
    setAnswers(prevAnswers => prevAnswers.map(answer => 
      answer.id === answerId 
        ? { 
            ...answer, 
            comments: answer.comments.map(comment => 
              comment.id === commentId 
                ? { 
                    ...comment, 
                    likes: comment.hasLiked ? comment.likes - 1 : comment.likes + 1,
                    hasLiked: !comment.hasLiked // Toggle the like status
                  } 
                : comment
            ) 
          } 
        : answer
    ));
  };

  const navigateToAnswerDetail = () => {
    navigation.navigate('AnswerDetailScreen', { addAnswer });
  };

  const handleCommentClick = (answerId) => {
    setCommenting(answerId);
    Keyboard.dismiss(); // Dismiss keyboard when starting to comment
  };

  const handleCloseCommentInput = () => {
    setCommenting(null);
  };

  const renderComments = (comments, answerId) => (
    <View>
      {comments && comments.map((comment, index) => (
        <View key={index} style={styles.commentContainer}>
          <Text style={styles.commentUsername}>{comment.username}</Text>
          <Text style={styles.commentContent}>{comment.content}</Text>
          <Text style={styles.commentTime}>{formatRelativeTime(comment.time)}</Text>
          <View style={styles.commentActions}>
            <TouchableOpacity onPress={() => toggleCommentLike(answerId, comment.id)} style={styles.iconWithText}>
              <FontAwesome name={comment.hasLiked ? "heart" : "heart-o"} size={14} color="black" />
              <Text> {comment.likes}</Text>
            </TouchableOpacity>
            <TouchableOpacity>
              <Ionicons name="ellipsis-horizontal" size={14} color="black" />
            </TouchableOpacity>
          </View>
        </View>
      ))}
      {commenting === answerId && (
        <AddComment answerId={answerId} addComment={addComment} onClose={handleCloseCommentInput} />
      )}
    </View>
  );

  const sortedAnswers = [...answers].sort((a, b) => new Date(a.time) - new Date(b.time)); // Sort answers by creation time

  return (
    <Provider>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backIcon} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={30} color="white" />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.headerTitle}>취업게시판</Text>
            <Text style={styles.headerSubtitle}>{selectedUniversity}</Text>
          </View>
          <Menu
            visible={menuVisible}
            onDismiss={() => setMenuVisible(false)}
            anchor={
              <TouchableOpacity style={styles.menuButton} onPress={() => setMenuVisible(true)}>
                <Ionicons name="ellipsis-vertical" size={30} color="white" />
              </TouchableOpacity>
            }
          >
            <Menu.Item onPress={() => alert('수정하기')} title="수정하기" />
            <Menu.Item onPress={() => alert('삭제하기')} title="삭제하기" />
            <Menu.Item onPress={() => alert('신고하기')} title="신고하기" />
          </Menu>
        </View>
        <FlatList
          ListHeaderComponent={
            <View style={styles.postContainer}>
              <View style={styles.postHeader}>
                <Text style={styles.title}>{post.title}</Text>
                <Text style={styles.username}>{post.username}</Text>
              </View>
              <Text style={styles.content}>{post.content}</Text>
              <Text style={styles.time}>{formatRelativeTime(post.time)}</Text>
              <View style={styles.interactions}>
                <TouchableOpacity onPress={toggleLike} style={styles.iconWithText}>
                  <FontAwesome name={liked ? "heart" : "heart-o"} size={14} color="black" />
                  <Text> 공감 {likes}</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={toggleScrap} style={styles.iconWithText}>
                  <FontAwesome name={scrapped ? "bookmark" : "bookmark-o"} size={14} color="black" />
                  <Text> 스크랩</Text>
                </TouchableOpacity>
              </View>
            </View>
          }
          data={sortedAnswers}
          renderItem={({ item }) => (
            <View style={styles.answerContainer}>
              <Text style={styles.answerTitle}>{item.title}</Text>
              <Text style={styles.answerContent}>{item.content}</Text>
              {item.media && <Image source={{ uri: item.media }} style={styles.answerMedia} />}
              <View style={styles.answerFooter}>
                <TouchableOpacity onPress={() => handleCommentClick(item.id)} style={styles.commentButton}>
                  <Ionicons name="chatbubble-outline" size={24} color="black" />
                </TouchableOpacity>
                <Text style={styles.answerUsername}>{item.username}</Text>
                <Text style={styles.answerTime}>{formatRelativeTime(item.time)}</Text>
              </View>
              {renderComments(item.comments, item.id)}
            </View>
          )}
          keyExtractor={(item) => item.id}
        />
        {commenting === null && (
          <TouchableOpacity style={styles.floatingButton} onPress={navigateToAnswerDetail}>
            <Ionicons name="add" size={30} color="white" />
          </TouchableOpacity>
        )}
      </View>
    </Provider>
  );
};

const AddComment = ({ answerId, addComment, onClose }) => {
  const [comment, setComment] = useState('');

  const handleAddComment = () => {
    const newComment = {
      id: Math.random().toString(),
      content: comment,
      username: '사용자2',
      likes: 0,
      hasLiked: false, // Track if the comment is liked
      time: new Date().toISOString(),
    };

    addComment(answerId, newComment);
    setComment('');
    onClose(); // Close the input box after adding comment
  };

  return (
    <View style={styles.addCommentContainer}>
      <TextInput
        style={styles.commentInput}
        value={comment}
        onChangeText={setComment}
        placeholder="댓글을 입력하세요"
      />
      <Button title="작성" onPress={handleAddComment} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  header: {
    backgroundColor: '#2c3e50',
    paddingTop: 40,
    paddingBottom: 10,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backIcon: {
    position: 'absolute',
    left: 16,
    top: 45,
  },
  headerTextContainer: {
    flex: 1,
    alignItems: 'center',
    left : 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#ffffff',
  },
  menuButton: {
    marginLeft: 'auto',
  },
  postContainer: {
    padding: 16,
    backgroundColor: '#ffffff',
    margin: 16,
    borderRadius: 8,
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  username: {
    fontSize: 14,
    color: '#7f8c8d',
  },
  content: {
    fontSize: 16,
    marginVertical: 8,
  },
  time: {
    fontSize: 12,
    color: '#bdc3c7',
  },
  interactions: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 10,
  },
  iconWithText: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 5,
  },
  answerContainer: {
    padding: 16,
    backgroundColor: '#ffffff',
    margin: 16,
    borderRadius: 8,
  },
  answerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  answerContent: {
    fontSize: 14,
    marginVertical: 8,
  },
  answerMedia: {
    width: '100%',
    height: 200,
    marginVertical: 10,
  },
  answerFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  answerUsername: {
    fontSize: 12,
    color: '#7f8c8d',
    marginRight: 10,
  },
  answerTime: {
    fontSize: 12,
    color: '#bdc3c7',
  },
  commentContainer: {
    backgroundColor: '#f9f9f9',
    padding: 8,
    borderRadius: 5,
    marginTop: 10,
  },
  commentUsername: {
    fontWeight: 'bold',
    color: '#7f8c8d',
    marginBottom: 4,
  },
  commentContent: {
    fontSize: 12,
    marginVertical: 4,
  },
  commentTime: {
    fontSize: 12,
    color: '#bdc3c7',
  },
  commentActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  addCommentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  commentInput: {
    flex: 1,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 10,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#2c3e50',
    borderRadius: 50,
    padding: 10,
  },
  commentButton: {
    marginRight: 10,
  },
});

export default PostDetailScreen;
