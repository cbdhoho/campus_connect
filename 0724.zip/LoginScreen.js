// LoginScreen.js

import React from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { FontAwesome } from "@expo/vector-icons";

const LoginScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <FontAwesome
        name="user-circle-o"
        size={100}
        color="#ffffff"
        style={styles.icon}
      />
      <Text style={styles.text}>로그인</Text>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>아이디</Text>
        <TextInput
          style={styles.input}
          placeholder="아이디"
          placeholderTextColor="#ffffff"
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>비밀번호</Text>
        <TextInput
          style={styles.input}
          placeholder="비밀번호"
          placeholderTextColor="#ffffff"
          secureTextEntry={true}
        />
      </View>
      <TouchableOpacity
        style={styles.loginButton}
        onPress={() => {
          // 로그인 성공 후 처리할 내용
          // 예시로 홈 화면으로 이동하는 navigate를 사용
          navigation.navigate("Home");
        }}
      >
        <Text style={styles.loginButtonText}>로그인</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate("Signup")}>
        <Text style={styles.signupText}>회원가입</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#3498db", // 파란색 배경
  },
  icon: {
    marginBottom: 20,
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#ffffff", // 흰색 글자
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "80%",
    marginBottom: 10,
  },
  label: {
    width: 80,
    fontSize: 16,
    color: "#ffffff", // 흰색 글자
  },
  input: {
    flex: 1,
    height: 40,
    backgroundColor: "#ffffff", // 흰색 배경
    paddingLeft: 10,
  },
  loginButton: {
    backgroundColor: "#f39c12", // 주황색 배경
    padding: 10,
    borderRadius: 5,
    width: "80%",
    alignItems: "center",
    marginTop: 20,
  },
  loginButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  signupText: {
    marginTop: 20,
    color: "#ffffff", // 흰색 글자
    textDecorationLine: "underline",
  },
});

export default LoginScreen;
