import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { Provider } from 'react-native-paper';


const SchoolLifeBoardScreen = () => {
  const [posts, setPosts] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    // Fetch the posts from an API or database
    // For demo purposes, we use static data
    setPosts([
      { id: '1', title: '질문 제목 1', content: '질문 내용 1', time: '10분전', comments: 2, likes: 5, scrapped: false, liked: false },
      { id: '2', title: '질문 제목 2', content: '질문 내용 2', time: '20분전', comments: 1, likes: 3, scrapped: true, liked: false },
      { id: '3', title: '질문 제목 3', content: '질문 내용 3', time: '30분전', comments: 0, likes: 1, scrapped: false, liked: false },
    ]);
  }, []);

  const toggleLike = (id) => {
    setPosts(posts.map(post => post.id === id ? { ...post, likes: post.likes + (post.liked ? -1 : 1), liked: !post.liked } : post));
  };

  const toggleScrap = (id) => {
    setPosts(posts.map(post => post.id === id ? { ...post, scrapped: !post.scrapped } : post));
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.postContainer} onPress={() => navigation.navigate('PostDetailScreen', { post: item })}>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.content}>{item.content}</Text>
      <Text style={styles.time}>{item.time}</Text>
      <View style={styles.separator} />
      <View style={styles.interactions}>
        <Text style={styles.interactionText}>댓글 {item.comments}</Text>
        <TouchableOpacity onPress={() => toggleLike(item.id)} style={styles.iconWithText}>
          <FontAwesome name={item.liked ? "heart" : "heart-o"} size={14} color="black" />
          <Text style={styles.interactionText}>공감 {item.likes}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => toggleScrap(item.id)} style={styles.iconWithText}>
          <FontAwesome name={item.scrapped ? "bookmark" : "bookmark-o"} size={14} color="black" />
          <Text style={styles.interactionText}>스크랩</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <Provider>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backIcon} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={30} color="white" />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.headerTitle}>학교생활게시판</Text>
            <Text style={styles.headerSubtitle}>한국기술교육대학교</Text>
          </View>
          <View style={styles.headerIcons}>
            <TouchableOpacity style={styles.searchIcon} onPress={() => navigation.navigate('Search')}>
              <Ionicons name="search" size={24} color="white" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('MyPage')}>
            <Ionicons name="person" size={24} color="white" />
            </TouchableOpacity>
          </View>
        </View>
        <FlatList
          data={posts}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
        />
      </View>
    </Provider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#3498db',
  },
  header: {
    backgroundColor: '#2c3e50',
    paddingTop: 40,
    paddingBottom: 10,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backIcon: {
    position: 'absolute',
    left: 16,
    top: 45,
  },
  headerTextContainer: {
    alignItems: 'center',
    //justifyContent : 'center'
    flex : 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    alignItems : "center",
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#ffffff',
    marginBottom: 5,
  },
  headerIcons: {
    flexDirection: 'row',
    position: 'absolute',
    right: 16,
    top: 45,
  },
  searchIcon: {
    marginRight : 10,

  },
  infoIcon: {
    marginRight : 0
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    fontSize: 16,
  },
  listContainer: {
    paddingHorizontal: 0,
    paddingVertical: 8,
  },
  postContainer: {
    backgroundColor: '#f0f0f0',
    padding: 15,
    marginVertical: 8,
    //borderRadius: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  content: {
    fontSize: 14,
    marginVertical: 4,
  },
  time: {
    fontSize: 12,
    color: '#888',
    textAlign: 'right',
  },
  separator: {
    height: 1,
    backgroundColor: '#ccc',
    marginVertical: 8,
  },
  interactions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  interactionText: {
    marginLeft: 4,
  },
  iconWithText: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 10,
  },
});

export default SchoolLifeBoardScreen;
