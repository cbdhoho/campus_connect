import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const MyPageScreen = () => {
  const [nickname, setNickname] = useState("홍길동");
  const [email, setEmail] = useState("honggildong@example.com");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleChangeAccountInfo = () => {
    // 계정 정보 변경 로직
    console.log("Account info changed");
  };

  const handleDeletePost = (postId) => {
    // 게시글 삭제 로직
    console.log(`Post ${postId} deleted`);
  };

  const handleDeleteComment = (commentId) => {
    // 댓글 삭제 로직
    console.log(`Comment ${commentId} deleted`);
  };

  const deleteAccount = () => {
    // 회원탈퇴 로직
    Alert.alert("회원탈퇴", "회원탈퇴가 완료되었습니다.", [{ text: "확인" }]);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="person-circle" size={100} color="#3498db" />
        <Text style={styles.welcomeText}>반가워요, {nickname}님</Text>
      </View>

      <View style={styles.section}>
        <TouchableOpacity
          style={styles.optionButton}
          onPress={() => {
            // Navigate to account info change screen
            console.log("Navigate to account info change screen");
          }}
        >
          <Text style={styles.optionText}>계정 정보 변경</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>내가 쓴 게시글 & 댓글</Text>
        <TouchableOpacity
          style={styles.optionButton}
          onPress={() => {
            // Navigate to posts management
            console.log("Navigate to posts management");
          }}
        >
          <Text style={styles.optionText}>게시글 관리</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.optionButton}
          onPress={() => {
            // Navigate to comments management
            console.log("Navigate to comments management");
          }}
        >
          <Text style={styles.optionText}>댓글 관리</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.optionButton}
          onPress={() => {
            // Navigate to liked posts management
            console.log("Navigate to liked posts management");
          }}
        >
          <Text style={styles.optionText}>좋아요 관리</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>회원탈퇴</Text>
        <TouchableOpacity style={styles.deleteButton} onPress={deleteAccount}>
          <Text style={styles.deleteButtonText}>회원탈퇴</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    padding: 20,
  },
  header: {
    alignItems: "center",
    marginBottom: 30,
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#2c3e50",
    marginTop: 10,
  },
  section: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#3498db",
    marginBottom: 15,
  },
  optionButton: {
    backgroundColor: "#3498db",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    marginBottom: 10,
  },
  optionText: {
    color: "#ffffff",
    fontSize: 16,
  },
  deleteButton: {
    backgroundColor: "#e74c3c",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
  deleteButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
});

export default MyPageScreen;
